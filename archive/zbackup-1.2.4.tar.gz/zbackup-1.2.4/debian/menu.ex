?package(zbackup):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="zbackup" command="/usr/bin/zbackup"
